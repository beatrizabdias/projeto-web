// src/pages/playlists/Playlists.jsx

import React from 'react';
import PlaylistCard from '../../components/playlists/PlaylistCard';
import AddPlaylistCard from '../../components/playlists/AddPlaylist';
import './Playlists.css'; 

// Ajuste do caminho da imagem: agora ele volta 2 pastas (../..) para chegar ao src
import vacaImage from '../../assets/img/vacateste.jpg'; 

// Use a variável importada nos dados de exemplo
const playlistsMockData = [
  { id: 1, nome: 'Nome playlist 1', imagem: vacaImage },
  { id: 2, nome: 'Nome playlist 2', imagem: vacaImage },
  { id: 3, nome: 'Nome playlist 3', imagem: vacaImage },
];

function Playlists() {
  return (
    <main>
      <h1>Minhas Playlists</h1>
      <div className="playlists-container">
        <AddPlaylistCard />
        {playlistsMockData.map(playlist => (
          <PlaylistCard key={playlist.id} playlist={playlist} />
        ))}
      </div>
    </main>
  );
}

export default Playlists;