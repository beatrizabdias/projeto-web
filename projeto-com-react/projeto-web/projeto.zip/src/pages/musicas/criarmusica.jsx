import React from 'react';

function BotaoUp(props) {

    return (
    
        <div>

            <label>Enviar arquivo:</label>
            <button>Fazer Upload</button>

        </div>

    );

}