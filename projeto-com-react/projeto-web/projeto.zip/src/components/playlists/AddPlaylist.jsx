import React from 'react';

function AddPlaylistCard() {
  return (
    <div className="add-playlist">
      <button className="btn-add-playlist">
        <i className="fas fa-plus"></i>
      </button>
      <p>Nova Playlist</p>
    </div>
  );
}

export default AddPlaylistCard;